<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendar extends MY_Controller {


  public function __construct(){
  	parent::__construct();
  	
  }


  public function index(){
    $this->reder_view('main/fullCalenderView');

  }

  public function getBookingCountByDate(){
    $date = $this->input->post('date');
    $response = array();
    $response['bookings'] = $this->LoginModel->countBookingsBydate($date);
    $data = $response['bookings']['bookings'];

    for($i=0;$i<count($response['bookings']);$i++){
      $data[$i]->booking_hour = $this->LoginModel->searchHourName($data[$i]->booking_hour);
    }
    $response['isBlocked'] = $this->LoginModel->checkDateIsBlocked($date);

    echo json_encode($response);
  }

}
