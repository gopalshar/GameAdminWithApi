(function ($) {
    "use strict";
    
    /*Dropify*/
    if( $('.dropify').length ) {
        $('.dropify').dropify();
    }
    
})(jQuery);